#Aluno: Victor Bernardo Gomes de Tatagiba
#Matricula:202211960
#P2
class Pessoa:
    def __init__(self,nome,idade,sexo,):
        self.nome= nome 
        self.idade = idade
        self.sexo = sexo
    
    def dados(self,nome,idade,sexo):
        nome=self.nome
        idade=self.idade
        sexo=self.sexo
        Pessoa(nome,idade,sexo)