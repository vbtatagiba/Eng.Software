// Acessa o formulário pelo ID
const form = document.getElementById("myForm");

// Adiciona um listener de evento para o envio do formulário
form.addEventListener("submit", function(event) {
  // Cancela o comportamento padrão do formulário (enviar)
  event.preventDefault();
  
  // Obtém os valores dos campos
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const message = document.getElementById("message").value;
  
  // Faz alguma coisa com os valores obtidos (por exemplo, enviar para um servidor)
  console.log(`Nome: ${name}\nEmail: ${email}\nMensagem: ${message}`);
  
  // Exibe a mensagem de formulário enviado
  const messageContainer = document.getElementById("message-container");
  messageContainer.innerHTML = "Formulário enviado!";
  
  // Limpa os campos do formulário
  form.reset();
});
