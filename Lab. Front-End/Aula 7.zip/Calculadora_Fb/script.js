let input = document.getElementById('result');

function addToInput(val) {
    input.value += val;
}

function clearAll() {
    input.value = '';
}

function clearOne() {
    input.value = input.value.slice(0, -1);
}

function calculate() {
    let expression = input.value;
    let result = eval(expression);

    input.value = result;
}
