<?php
// Inclui o arquivo de conexão com o banco de dados
include 'conexao.php';

// Verifica se os dados foram enviados via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtém os dados do formulário
    $matricula = $_POST['Matricula'];
    $novoNome = $_POST['NovoNome'];
    $novoEstado = $_POST['NovoEstado'];

    // Prepara a consulta SQL para atualização do aluno pelo ID (Matrícula)
    $sql = "UPDATE aluno SET Nome = ?, Estado = ? WHERE Matricula = ?";

    // Prepara a declaração SQL
    $stmt = $conn->prepare($sql);
    
    // Verifica se a preparação da declaração foi bem-sucedida
    if ($stmt === false) {
        die('Erro ao preparar a consulta: ' . $conn->error);
    }

    // Liga os parâmetros à declaração
    $stmt->bind_param('ssi', $novoNome, $novoEstado, $matricula); // 'ssi' indica string, string, inteiro

    // Executa a declaração
    $stmt->execute();

    // Verifica se a atualização afetou alguma linha
    if ($stmt->affected_rows > 0) {
        echo "Aluno alterado com sucesso!";
    } else {
        echo "Nenhum aluno encontrado com a Matrícula especificada.";
    }

    // Fecha a declaração
    $stmt->close();
}
// Fecha a conexão com o banco de dados
$conn->close();
?>
