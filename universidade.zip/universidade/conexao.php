<?php
$servername = "localhost:3307"; // Endereço do servidor MySQL (com a porta)
$username = "root"; // Nome de usuário do MySQL (padrão é 'root')
$password = "vassouras123"; // Senha do MySQL
$database = "universidade"; // Nome do banco de dados

// Cria a conexão
$conn = new mysqli($servername, $username, $password, $database);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}
?>
