<?php
// Inclui o arquivo de conexão com o banco de dados
include 'conexao.php';

// Prepara a consulta SQL para selecionar todos os alunos
$sql = "SELECT Matricula, Nome, Estado FROM aluno";

// Executa a consulta
$result = $conn->query($sql);

// Verifica se há resultados na consulta
if ($result->num_rows > 0) {
    // Início do HTML que será exibido
    echo "<!DOCTYPE html>";
    echo "<html>";
    echo "<head>";
    echo "<title>Relatório Geral de Alunos</title>";
    echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
    echo "<style>";
    echo "table {";
    echo "  width: 100%;";
    echo "  border-collapse: collapse;";
    echo "}";
    echo "table, th, td {";
    echo "  border: 1px solid black;";
    echo "}";
    echo "th, td {";
    echo "  padding: 8px;";
    echo "  text-align: left;";
    echo "}";
    echo "</style>";
    echo "</head>";
    echo "<body>";
    echo "<h3>Relatório Geral de Alunos - Universidade de Vassouras</h3>";
    echo "<br><br>";
    // Início da tabela HTML
    echo "<table>";
    echo "<tr><th>Matrícula</th><th>Nome</th><th>Estado</th></tr>";
    
    // Loop para exibir cada aluno encontrado
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row["Matricula"]) . "</td>"; // htmlspecialchars para evitar XSS
        echo "<td>" . htmlspecialchars($row["Nome"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["Estado"]) . "</td>";
        echo "</tr>";
    }
    
    // Fim da tabela e do HTML
    echo "</table>";
    echo "</body>";
    echo "</html>";
} else {
    echo "Nenhum aluno encontrado.";
}

// Fecha a conexão com o banco de dados
$conn->close();
?>
