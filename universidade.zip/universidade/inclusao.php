<?php
include 'conexao.php'; // Inclui o arquivo de conexão

// Verifica se os dados foram enviados via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $estado = $_POST['estado'];

    // Prepara a consulta SQL para inserção
    $sql = "INSERT INTO aluno (nome, estado) VALUES ('$nome', '$estado')";

    // Executa a consulta
    if ($conn->query($sql) === TRUE) {
        echo "Registro inserido com sucesso!";
    } else {
        echo "Erro ao inserir registro: " . $conn->error;
    }
}

// Fecha a conexão
$conn->close();
?>
