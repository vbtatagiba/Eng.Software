<?php
// Inclui o arquivo de conexão com o banco de dados
include 'conexao.php';

// Verifica se a conexão foi estabelecida corretamente
if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

// Prepara a consulta SQL para selecionar todos os alunos
$sql = "SELECT matricula, nome, estado FROM aluno";
$result = $conn->query($sql);

// Verifica se a consulta foi executada com sucesso
if ($result === false) {
    echo "Erro ao executar a consulta: " . $conn->error;
} else {
    // Verifica se há resultados na consulta
    if ($result->num_rows > 0) {
        // Início do HTML que será exibido
        echo "<!DOCTYPE html>";
        echo "<html>";
        echo "<head>";
        echo "<title>Consulta de Alunos - Universidade de Vassouras</title>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "</head>";
        echo "<body>";
        echo "<h2>Consulta de Alunos - Universidade de Vassouras</h2>";
        echo "<br><br>";
        // Início da tabela HTML
        echo "<table border='1'>";
        echo "<tr><th>matricula</th><th>Nome</th><th>Estado</th></tr>";
        
        // Loop para exibir cada aluno encontrado
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["matricula"] . "</td>";
            echo "<td>" . $row["nome"] . "</td>";
            echo "<td>" . $row["estado"] . "</td>";
            echo "</tr>";
        }
        
        // Fim da tabela e do HTML
        echo "</table>";
        echo "</body>";
        echo "</html>";
    } else {
        // Caso não haja alunos cadastrados
        echo "Nenhum aluno encontrado.";
    }
}

// Fecha a conexão com o banco de dados
$conn->close();
?>
