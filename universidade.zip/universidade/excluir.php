<?php
// Inclui o arquivo de conexão com o banco de dados
include 'conexao.php';

// Verifica se a Matrícula do aluno foi enviada via GET
if (isset($_GET['Matricula'])) {
    $matricula = $_GET['Matricula'];

    // Prepara a consulta SQL para exclusão do aluno pelo ID (Matrícula)
    $sql = "DELETE FROM aluno WHERE Matricula = ?";

    // Prepara a declaração SQL
    $stmt = $conn->prepare($sql);
    
    // Verifica se a preparação da declaração foi bem-sucedida
    if ($stmt === false) {
        die('Erro ao preparar a consulta: ' . $conn->error);
    }

    // Liga o parâmetro à declaração
    $stmt->bind_param('i', $matricula);

    // Executa a declaração
    $stmt->execute();

    // Verifica se a exclusão afetou alguma linha
    if ($stmt->affected_rows > 0) {
        echo "Aluno removido com sucesso!";
    } else {
        echo "Nenhum aluno encontrado com a Matrícula especificada.";
    }

    // Fecha a declaração
    $stmt->close();
} else {
    echo "Matrícula do aluno não especificada.";
}

// Fecha a conexão com o banco de dados
$conn->close();
?>
