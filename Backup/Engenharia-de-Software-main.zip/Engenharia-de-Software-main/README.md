# Engenharia de Software - 2022

Repositório para Exercícios, Trabalhos e Projetos desenvolvidos por Hygor Rasec durante o curso de graduação.

## Atualizações

**> Projeto DMS e Universidade de Vassouras > Prova de Seleção:**
 - Criação de um programa que realize a Conversão de Medidas. Criado em 26/03/2022.

**> Trabalho > Pensamento Computacional ESW01_B:**
 - Adicionado pasta com Sistema de Votação - PyScript. Criado em 07/05/2022.

**> Exercícios de Fixação:**
 - Adicionado arquivo com Exercícios de Fixação com Variáveis e Tipo de Dados em Python. Criado em 09/04/2022.
 - Adicionado arquivo com Exercícios de Fixação com Estruturas Lógicas e Condicionais em Python. Criado em 14/04/2022.
