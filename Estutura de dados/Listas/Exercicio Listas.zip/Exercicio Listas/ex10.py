
nomes = ["João", "Maria", "José", "Ana", "Carlos"]

print("Primeiro nome:", nomes[0])
print("Último nome:", nomes[-1])