from fila import Fila
from random import randint

fila= Fila()

fila.enqueue(('Marcio',45))
fila.enqueue(('Alexandre',78))
fila.enqueue(('Dias',46))
fila.enqueue(('Victor',32))
fila.enqueue(('Maria',35))
fila.enqueue(('Eduardo',35))
fila.enqueue(('Roberta',38))
fila.enqueue(('Fabio',48))


fila.exibir()

fila.idade()


fila.exibir()