'''5. Faça um Programa que peça o raio de um círculo, calcule e mostre sua área.'''
n1=float(input('Insira o raio do círculo:'))
pi=3.14
area=3.14*n1**2
print ('A área do Círculo é:',area)