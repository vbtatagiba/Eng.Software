'''4. Faça um Programa que converta metros para centímetros.'''
metros=float(input('informe quantos metros a ser convertido para centímetros:'))
cm = metros * 100
print('o resuldado da conversão é ',cm)