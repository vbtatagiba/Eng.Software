n1=int(input("digite um numero: "))
n2=int(input("digite outro numero: "))
while n2<n1:
	n1=int(input("digite um numero: "))
	n2=int(input("digite outro numero: "))
    
else:
	for i in range(n1,n2,1):
		print(i)