'''2. Faça um Programa que peça dois números e imprima a soma.'''
n1=int(input('Digite o Primeiro Número:'))
n2=int(input('Digite o Segundo Número:'))
soma=n1+n2
print('O Resultado da Soma é',soma)