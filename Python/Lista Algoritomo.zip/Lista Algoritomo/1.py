'''1. Faça um Programa que peça um número e então mostre a mensagem O número informado foi
[número]'''
n1=int(input('Insira o Número Desejado:'))
print('O Número inserido foi:',n1)
