"""22. Faça um programa que leia 5 números e informe a soma e a média dos números"""
n1=int(input('Primeiro número: '))
n2=int(input('Segundo número: '))
n3=int(input('Terceiro número: '))
n4=int(input('Quarto número: '))
n5=int(input('Quinto número: '))
soma=n1+n2+n3+n4+n5
media=soma/5
print('A soma dos Numeros é: ', soma)
print('A Média dos Numeros é: ',media)