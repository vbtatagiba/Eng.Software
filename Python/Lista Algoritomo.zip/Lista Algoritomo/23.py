"""23. Faça um programa que imprima na tela apenas os números ímpares entre 1 e 50""" 
for i in range(1,51,2):
    print (i)